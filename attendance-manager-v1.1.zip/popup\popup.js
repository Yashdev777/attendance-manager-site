// ​‌​‌‌​​‌‍​‌​​​​​‌‍​‌​‌​​‌‌‍​‌​​‌​​​‍​​‌​​​​​‍​‌​​​​‌​‍​‌​​‌​​​‍​‌​​​​​‌‍​‌​‌​‌​​‍​‌​​‌‌‌​‍​‌​​​​​‌‍​‌​​​‌‌‌‍​‌​​​​​‌‍​‌​‌​​‌​‍​​‌​​​​​‍​‌‌‌‌‌​​‍​​‌​​​​​‍​‌​​‌​‌‌‍​‌​​‌​​‌‍​‌​​​‌​‌‍​‌​‌​‌​​‍​​‌​​​​​‍​‌​​​​‌‌‍​‌​‌​​‌‌‍​‌​​​‌​‌‍​​‌​​​​​‍​​‌‌​​‌​‍​​‌‌​​​​‍​​‌‌​​‌‌‍​​‌‌​​​​‍​​‌​​​​​‍​‌‌‌‌‌​​‍​​‌​​​​​‍​‌​​​​​‌‍​‌​‌​‌​​‍​‌​‌​‌​​‍​‌​​​‌​‌‍​‌​​‌‌‌​‍​‌​​​‌​​‍​‌​​​​​‌‍​‌​​‌‌‌​‍​‌​​​​‌‌‍​‌​​​‌​‌‍​​‌​​​​​‍​‌​​‌‌​‌‍​‌​​​​​‌‍​‌​​‌‌‌​‍​‌​​​​​‌‍​‌​​​‌‌‌‍​‌​​​‌​‌‍​‌​‌​​‌​‍​​‌​​​​​‍​‌​​​‌​‌‍​‌​‌​​‌​‍​‌​‌​​​​‍​​‌​​​​​‍​‌​​‌​‌‌‍​‌​​​​​‌‍​​‌​​​​​‍​‌​​​​‌‌‍​‌​​‌​​​‍​‌​​​​​‌‍​‌​​​​‌‌‍​‌​​‌​​​‍​‌​​​​​‌‍
document.addEventListener('DOMContentLoaded', () => {
  const subjectList = document.getElementById('subject-list');
  const syncBtn = document.getElementById('sync-btn');
  const lastSyncEl = document.getElementById('last-sync');
  const gearBtn = document.getElementById('gear-btn');

  gearBtn.addEventListener('click', (e) => {
    e.preventDefault();
    chrome.runtime.openOptionsPage();
  });

  syncBtn.addEventListener('click', async () => {
    syncBtn.textContent = '🔄 Syncing...';
    syncBtn.disabled = true;
    try {
      const result = await triggerSync();
      if (result.success) {
        syncBtn.textContent = '✓ Synced';
        setTimeout(() => {
          syncBtn.textContent = '🔄 Sync Now';
          syncBtn.disabled = false;
        }, 2000);
      } else {
        syncBtn.textContent = '❌ Error';
        if (result.error === 'NOT_LOGGED_IN' || result.error.includes('451') || result.error.includes('401')) {
          showLoginRequired();
        }
        setTimeout(() => {
          syncBtn.textContent = '🔄 Sync Now';
          syncBtn.disabled = false;
        }, 2000);
      }
    } catch (e) {
      syncBtn.textContent = '❌ Error';
      console.error('Sync error:', e);
      setTimeout(() => {
        syncBtn.textContent = '🔄 Sync Now';
        syncBtn.disabled = false;
      }, 2000);
    }
  });

  updateLastSync();
  loadAttendance();

  async function triggerSync() {
    try {
      console.log('[POPUP] Sending SYNC_NOW message...');

      const response = await Promise.race([
        chrome.runtime.sendMessage({ type: 'SYNC_NOW' }),
        new Promise((_, reject) =>
          setTimeout(() => reject(new Error('Message timeout')), 30000)
        )
      ]);

      console.log('[POPUP] Sync response:', response);

      if (response && response.success) {
        await loadAttendance();
        await updateLastSync();
        return { success: true };
      } else {
        return { success: false, error: response?.error || 'Unknown error' };
      }
    } catch (e) {
      console.error('[POPUP] Sync failed:', e.message);

      if (e.message.includes('Receiving end does not exist')) {
        console.log('[POPUP] Service worker was asleep. Retrying...');
        await new Promise(r => setTimeout(r, 500));
        try {
          const retry = await chrome.runtime.sendMessage({ type: 'SYNC_NOW' });
          if (retry && retry.success) {
            await loadAttendance();
            await updateLastSync();
            return { success: true };
          }
        } catch (retryErr) {
          console.error('[POPUP] Retry failed:', retryErr.message);
        }
      }
      return { success: false, error: e.message };
    }
  }

  function showLoginRequired() {
    subjectList.innerHTML = `
      <div class="empty-state">
        <p>⚠️ Please login to ERP first.</p>
        <br>
        <button id="open-erp-btn" style="padding:10px 20px;background:#667eea;color:white;border:none;border-radius:6px;cursor:pointer;font-size:14px;">Open ERP</button>
      </div>
    `;
    document.getElementById('open-erp-btn').addEventListener('click', () => {
      chrome.tabs.create({ url: 'https://erp.kiet.co.in/student' });
    });
  }

  async function loadAttendance() {
    const { snapshot, disputed = [] } = await chrome.storage.local.get(['snapshot', 'disputed']);
    if (snapshot && snapshot.length > 0) {
      renderSubjects(snapshot, disputed);
    } else {
      subjectList.innerHTML = '<div class="empty-state">Click Sync Now to load subjects</div>';
    }
  }

  function renderSubjects(subjects, disputed) {
    chrome.storage.local.get('subjectTargets').then(({ subjectTargets = {} }) => {
      const defaultTarget = EXT_CONFIG.DEFAULT_TARGET;
      const disputedMap = {};
      disputed.forEach(d => {
        disputedMap[d.course_uuid] = (disputedMap[d.course_uuid] || 0) + 1;
      });
      console.log('[POPUP] Disputed map:', disputedMap);

      const sorted = [...subjects].sort((a, b) => {
        const targetA = subjectTargets[a.course_uuid] || defaultTarget;
        const targetB = subjectTargets[b.course_uuid] || defaultTarget;
        const calcA = calcSubject(a, targetA, disputedMap[a.course_uuid] || 0);
        const calcB = calcSubject(b, targetB, disputedMap[b.course_uuid] || 0);
        const aBelow = calcA && calcA.currentPct < targetA;
        const bBelow = calcB && calcB.currentPct < targetB;
        if (aBelow && !bBelow) return -1;
        if (!aBelow && bBelow) return 1;
        return a.course_name.localeCompare(b.course_name);
      });

      subjectList.innerHTML = sorted.map(s => {
        const target = subjectTargets[s.course_uuid] || defaultTarget;
        const dispCount = disputedMap[s.course_uuid] || 0;
        console.log('[POPUP] Subject', s.course_name, 'has', dispCount, 'disputed');
        return renderCard(s, target, dispCount);
      }).join('');
    });
  }

  function renderCard(subject, target, disputedCount) {
    const effectiveAbsent = Math.max(0, subject.absent_count - disputedCount);
    const effectivePresent = subject.present_count + disputedCount;
    const effectiveTotal = subject.total_count;

    const calc = calcSubject({ ...subject, absent_count: effectiveAbsent, present_count: effectivePresent }, target, 0);
    if (!calc) return '';
    const isBelow = calc.currentPct < target;
    const cardClass = isBelow ? 'below-target' : 'above-target';
    const pctClass = isBelow ? 'bad' : 'good';
        let calcHtml = '';
    if (calc.impossible) {
      calcHtml = `<div class="calculator-result impossible">❌ 100% not possible — ${effectiveAbsent} class${effectiveAbsent > 1 ? 'es' : ''} already missed</div>`;
    } else if (calc.mustAttend > 0) {
      calcHtml = `<div class="calculator-result warning">⚠️ Must attend ${calc.mustAttend} lecture${calc.mustAttend > 1 ? 's' : ''}</div>`;
    } else {
      calcHtml = `<div class="calculator-result ok">✅ Can miss ${calc.maxMissable} lecture${calc.maxMissable !== 1 ? 's' : ''}</div>`;
    }
    const disputeBadge = disputedCount > 0 ? `<div class="disputed-badge">⚠️ ${disputedCount} disputed</div>` : '';
    const presentDisplay = disputedCount > 0 ? `Present: ${subject.present_count} (+${disputedCount} disputed)` : `Present: ${subject.present_count}`;
    return `
      <div class="subject-card ${cardClass}">
        <div class="subject-name">${subject.course_name}</div>
        <div class="subject-code">${subject.course_code}</div>
        <div class="subject-stats">
          <span class="percentage ${pctClass}">${calc.percentage}%</span>
          <span class="counts">${presentDisplay} | Absent: ${effectiveAbsent} | Total: ${effectiveTotal}</span>
          <span class="target-label">Target: ${target}%</span>
        </div>
        ${calcHtml}
        ${disputeBadge}
      </div>
    `;
  }

  async function updateLastSync() {
    console.log('[POPUP] Reading lastSyncTime');
    const data = await chrome.storage.local.get('lastSyncTime');
    console.log('[POPUP] lastSyncTime value:', data.lastSyncTime);
    if (data.lastSyncTime) {
      const mins = Math.floor((Date.now() - data.lastSyncTime) / 60000);
      lastSyncEl.textContent = mins <= 0 ? 'Last synced: just now' : `Last synced: ${mins} min ago`;
    }
  }
});
