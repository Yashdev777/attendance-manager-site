// ​‌​‌‌​​‌‍​‌​​​​​‌‍​‌​‌​​‌‌‍​‌​​‌​​​‍​​‌​​​​​‍​‌​​​​‌​‍​‌​​‌​​​‍​‌​​​​​‌‍​‌​‌​‌​​‍​‌​​‌‌‌​‍​‌​​​​​‌‍​‌​​​‌‌‌‍​‌​​​​​‌‍​‌​‌​​‌​‍​​‌​​​​​‍​‌‌‌‌‌​​‍​​‌​​​​​‍​‌​​‌​‌‌‍​‌​​‌​​‌‍​‌​​​‌​‌‍​‌​‌​‌​​‍​​‌​​​​​‍​‌​​​​‌‌‍​‌​‌​​‌‌‍​‌​​​‌​‌‍​​‌​​​​​‍​​‌‌​​‌​‍​​‌‌​​​​‍​​‌‌​​‌‌‍​​‌‌​​​​‍​​‌​​​​​‍​‌‌‌‌‌​​‍​​‌​​​​​‍​‌​​​​​‌‍​‌​‌​‌​​‍​‌​‌​‌​​‍​‌​​​‌​‌‍​‌​​‌‌‌​‍​‌​​​‌​​‍​‌​​​​​‌‍​‌​​‌‌‌​‍​‌​​​​‌‌‍​‌​​​‌​‌‍​​‌​​​​​‍​‌​​‌‌​‌‍​‌​​​​​‌‍​‌​​‌‌‌​‍​‌​​​​​‌‍​‌​​​‌‌‌‍​‌​​​‌​‌‍​‌​‌​​‌​‍​​‌​​​​​‍​‌​​​‌​‌‍​‌​‌​​‌​‍​‌​‌​​​​‍​​‌​​​​​‍​‌​​‌​‌‌‍​‌​​​​​‌‍​​‌​​​​​‍​‌​​​​‌‌‍​‌​​‌​​​‍​‌​​​​​‌‍​‌​​​​‌‌‍​‌​​‌​​​‍​‌​​​​​‌‍
importScripts('config.js', 'lib/debug.js', 'lib/api.js', 'lib/storage.js', 'lib/analytics.js');

async function doSync(isAutoTriggered = false) {
  console.log('[BG] doSync started');
  try {
    const subjects = await fetchAndNormalize();
    console.log('[BG] Subjects fetched:', subjects.length);

    const { snapshot: oldSnapshot = [] } = await chrome.storage.local.get('snapshot');
    const oldMap = {};
    oldSnapshot.forEach(s => { oldMap[s.course_uuid] = s; });

    const newAbsents = [];
    subjects.forEach(newSubj => {
      const oldSubj = oldMap[newSubj.course_uuid];
      if (oldSubj && newSubj.absent_count > oldSubj.absent_count) {
        newAbsents.push({ ...newSubj, diff: newSubj.absent_count - oldSubj.absent_count });
        console.log('[BG] Absent increased in', newSubj.course_name, ':', oldSubj.absent_count, '→', newSubj.absent_count);
      }
    });

    const { notificationsEnabled = true, soundEnabled = false } = await chrome.storage.local.get(['notificationsEnabled', 'soundEnabled']);

    if (notificationsEnabled) {
      const { notifMap = {} } = await chrome.storage.local.get('notifMap');
      for (const subj of newAbsents) {
        const notifId = 'absent-' + subj.course_uuid + '-' + Date.now();
        console.log('[BG] Creating notification with id:', notifId);

        notifMap[notifId] = { course_uuid: subj.course_uuid, course_name: subj.course_name };

        chrome.notifications.create(notifId, {
          type: 'basic',
          iconUrl: chrome.runtime.getURL('icons/icon128.png'),
          title: 'Attendance Alert — ERP ka chacha',
          message: `Aaj ${subj.course_name} me tum ABSENT mark hue ho.`,
          buttons: [{ title: 'Mark as Disputed' }, { title: 'Dismiss' }],
          priority: 2,
          requireInteraction: true,
          silent: !soundEnabled
        }, (id) => {
          if (chrome.runtime.lastError) {
            console.error('[BG] Notification failed:', chrome.runtime.lastError);
          } else {
            console.log('[BG] Notification created:', id);
          }
        });
      }
      await chrome.storage.local.set({ notifMap });
    }

    await chrome.storage.local.set({ snapshot: subjects, lastSyncTime: Date.now() });
    console.log('[BG] Sync complete. Subjects:', subjects.length, 'New absents:', newAbsents.length);

    await trackEvent('sync');
    return { count: subjects.length, newAbsents: newAbsents.length };
    } catch (e) {
    const msg = e.message || 'UNKNOWN_ERROR';
    console.error('[BG] Sync error:', msg);

    // --- Categorize error ---
    let errorType = 'UNKNOWN';
    let notifTitle = '⚠️ Sync Failed';
    let notifMessage = 'Attendance sync nahi ho paya. Options page check karo.';

    if (msg === 'NOT_LOGGED_IN' || msg.includes('401') || msg.includes('403') || msg.includes('451')) {
      errorType = 'NOT_LOGGED_IN';
      notifTitle = '⚠️ ERP Login Required';
      notifMessage = 'Attendance sync paused. ERP mein login karke phir try karo.';
    } else if (msg === 'SYNC_TIMEOUT' || msg.includes('408')) {
      errorType = 'SYNC_TIMEOUT';
      notifTitle = '⏱️ Sync Timed Out';
      notifMessage = 'ERP slow hai. Thodi der baad dobara try karo.';
    } else if (msg === 'FRAME_REMOVED' || msg.includes('499')) {
      errorType = 'FRAME_REMOVED';
      notifTitle = '🔄 Sync Interrupted';
      notifMessage = 'ERP page navigate ho gaya. Next auto-sync mein try karega.';
    } else if (msg.startsWith('ERP_ERROR')) {
      errorType = 'ERP_ERROR';
      notifTitle = '❌ ERP Error';
      notifMessage = 'ERP ne error diya: ' + msg;
    } else if (msg.includes('Unexpected response')) {
      errorType = 'BAD_RESPONSE';
      notifTitle = '❌ Bad ERP Response';
      notifMessage = 'ERP se unexpected data aaya. Extension update check karo.';
    }

    // --- Rate-limit: same error type 1 hour mein sirf 1 baar notify ---
    const notifKey = 'lastNotif_' + errorType;
    const stored = await chrome.storage.local.get(notifKey);
    const lastNotifTime = stored[notifKey];
    const oneHourAgo = Date.now() - 60 * 60 * 1000;

    if (!lastNotifTime || lastNotifTime < oneHourAgo) {
      chrome.notifications.create('sync-error-' + errorType + '-' + Date.now(), {
        type: 'basic',
        iconUrl: chrome.runtime.getURL('icons/icon128.png'),
        title: notifTitle,
        message: notifMessage,
        priority: 2
      });
      await chrome.storage.local.set({ [notifKey]: Date.now() });
    } else {
      console.log('[BG] Notification rate-limited for', errorType);
    }

    throw e;
  }
  
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  console.log('[BG] Message received:', msg.type);

  if (msg.type === 'SYNC_NOW') {
    doSync(true)
      .then(result => {
        console.log('[BG] Sync result:', result);
        sendResponse({ success: true, ...result });
      })
      .catch(err => {
        console.error('[BG] Sync error:', err.message);
        sendResponse({ success: false, error: err.message });
      });
    return true;  // Keep channel open for async response
  }

  if (msg.type === 'TEST_COOKIES') {
    chrome.cookies.getAll({}).then(cookies => {
      const kietCookies = cookies.filter(c => c.domain && c.domain.includes('kiet'));
      sendResponse({
        totalCookies: cookies.length,
        kietCookies: kietCookies.map(c => ({
          name: c.name,
          domain: c.domain,
          path: c.path,
          secure: c.secure,
          httpOnly: c.httpOnly,
          sameSite: c.sameSite
        })),
        allDomains: [...new Set(cookies.map(c => c.domain))]
      });
    });
    return true;  // Keep channel open for async response
  }

  sendResponse({ success: false, error: 'Unknown message type' });
  return false;
});

chrome.notifications.onButtonClicked.addListener(async (notifId, btnIdx) => {
  console.log('[BG] Button clicked:', notifId, 'btnIdx:', btnIdx);

  if (btnIdx === 0) {
    const { notifMap = {} } = await chrome.storage.local.get('notifMap');
    const subjectData = notifMap[notifId];

    if (!subjectData) {
      console.error('[BG] No subject data found for notifId:', notifId);
      return;
    }

    console.log('[BG] Recording dispute for:', subjectData);

    const { disputed = [] } = await chrome.storage.local.get('disputed');
    disputed.push({
      course_uuid: subjectData.course_uuid,
      course_name: subjectData.course_name,
      disputed_at: Date.now(),
      notifId: notifId
    });
    await chrome.storage.local.set({ disputed });
    console.log('[BG] Dispute saved. Total disputed:', disputed.length);

    delete notifMap[notifId];
    await chrome.storage.local.set({ notifMap });

    chrome.notifications.create('dispute-confirm-' + Date.now(), {
      type: 'basic',
      iconUrl: chrome.runtime.getURL('icons/icon128.png'),
      title: '✅ Dispute Recorded',
      message: `${subjectData.course_name} ka dispute save ho gaya. Teacher se check karwao.`,
      priority: 2
    });

    chrome.notifications.clear(notifId);
  } else if (btnIdx === 1) {
    console.log('[BG] Dismissed:', notifId);
    chrome.notifications.clear(notifId);
  }
});

chrome.notifications.onClicked.addListener((notifId) => {
  console.log('[BG] Notification clicked:', notifId);
  chrome.notifications.clear(notifId);
  chrome.runtime.openOptionsPage();
});

chrome.runtime.onInstalled.addListener(() => {
  console.log('[BG] Extension installed. Alarm set to 50 min.');
  chrome.alarms.clear('auto-sync', () => {
    chrome.alarms.create('auto-sync', { periodInMinutes: EXT_CONFIG.SYNC_INTERVAL_MIN });
    console.log('[BG] Alarm created on install:', EXT_CONFIG.SYNC_INTERVAL_MIN, 'min');
  });
});

chrome.runtime.onStartup.addListener(() => {
  console.log('[BG] Chrome started. Alarm set to 50 min.');
  chrome.alarms.clear('auto-sync', () => {
    chrome.alarms.create('auto-sync', { periodInMinutes: EXT_CONFIG.SYNC_INTERVAL_MIN });
    console.log('[BG] Alarm recreated:', EXT_CONFIG.SYNC_INTERVAL_MIN, 'min');
  });
});

chrome.alarms.onAlarm.addListener((alarm) => {
  console.log('[BG] Alarm fired:', alarm.name);
  if (alarm.name === 'auto-sync') {
    doSync(true).catch(e => console.error('[BG] Auto-sync failed:', e));
  }
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.syncInterval) {
    console.log('[BG] Sync interval changed to:', changes.syncInterval.newValue);
    chrome.alarms.clear('auto-sync', () => {
      chrome.alarms.create('auto-sync', { periodInMinutes: changes.syncInterval.newValue });
      console.log('[BG] Alarm recreated with new interval');
    });
  }
});
