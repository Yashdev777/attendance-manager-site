// ​‌​‌‌​​‌‍​‌​​​​​‌‍​‌​‌​​‌‌‍​‌​​‌​​​‍​​‌​​​​​‍​‌​​​​‌​‍​‌​​‌​​​‍​‌​​​​​‌‍​‌​‌​‌​​‍​‌​​‌‌‌​‍​‌​​​​​‌‍​‌​​​‌‌‌‍​‌​​​​​‌‍​‌​‌​​‌​‍​​‌​​​​​‍​‌‌‌‌‌​​‍​​‌​​​​​‍​‌​​‌​‌‌‍​‌​​‌​​‌‍​‌​​​‌​‌‍​‌​‌​‌​​‍​​‌​​​​​‍​‌​​​​‌‌‍​‌​‌​​‌‌‍​‌​​​‌​‌‍​​‌​​​​​‍​​‌‌​​‌​‍​​‌‌​​​​‍​​‌‌​​‌‌‍​​‌‌​​​​‍​​‌​​​​​‍​‌‌‌‌‌​​‍​​‌​​​​​‍​‌​​​​​‌‍​‌​‌​‌​​‍​‌​‌​‌​​‍​‌​​​‌​‌‍​‌​​‌‌‌​‍​‌​​​‌​​‍​‌​​​​​‌‍​‌​​‌‌‌​‍​‌​​​​‌‌‍​‌​​​‌​‌‍​​‌​​​​​‍​‌​​‌‌​‌‍​‌​​​​​‌‍​‌​​‌‌‌​‍​‌​​​​​‌‍​‌​​​‌‌‌‍​‌​​​‌​‌‍​‌​‌​​‌​‍​​‌​​​​​‍​‌​​​‌​‌‍​‌​‌​​‌​‍​‌​‌​​​​‍​​‌​​​​​‍​‌​​‌​‌‌‍​‌​​​​​‌‍​​‌​​​​​‍​‌​​​​‌‌‍​‌​​‌​​​‍​‌​​​​​‌‍​‌​​​​‌‌‍​‌​​‌​​​‍​‌​​​​​‌‍
document.addEventListener('DOMContentLoaded', () => {
  const defaultTargetInput = document.getElementById('default-target');
  const syncIntervalSelect = document.getElementById('sync-interval');
  const enableNotificationsCheckbox = document.getElementById('enable-notifications');
  const enableSoundCheckbox = document.getElementById('enable-sound');
  const analyticsToggle = document.getElementById('analytics-toggle');
  const subjectsContainer = document.getElementById('subjects-container');
  const applyDefaultBtn = document.getElementById('apply-default-btn');
  const resetAllBtn = document.getElementById('reset-all-btn');
  const applyChangesBtn = document.getElementById('apply-changes-btn');
  const clearDataBtn = document.getElementById('clear-data-btn');
  const testNotificationBtn = document.getElementById('test-notification-btn');
  const resetDefaultsBtn = document.getElementById('reset-defaults-btn');
  const confirmModal = document.getElementById('confirm-modal');
  const modalCancel = document.getElementById('modal-cancel');
  const modalConfirm = document.getElementById('modal-confirm');

  loadSettings();
  loadSubjects();
  loadDisputed();

  defaultTargetInput.addEventListener('change', () => {
    const val = parseInt(defaultTargetInput.value) || 75;
    chrome.storage.local.set({ defaultTarget: val });
    console.log('[OPTIONS] Saved: defaultTarget =', val);
    showToast('Settings saved');
  });

  syncIntervalSelect.addEventListener('change', () => {
    const val = parseInt(syncIntervalSelect.value);
    chrome.storage.local.set({ syncInterval: val });
    console.log('[OPTIONS] Saved: syncInterval =', val);
    showToast('Settings saved');
  });

  enableNotificationsCheckbox.addEventListener('change', () => {
    chrome.storage.local.set({ notificationsEnabled: enableNotificationsCheckbox.checked });
    console.log('[OPTIONS] Saved: notificationsEnabled =', enableNotificationsCheckbox.checked);
    showToast('Settings saved');
  });

  enableSoundCheckbox.addEventListener('change', () => {
    chrome.storage.local.set({ soundEnabled: enableSoundCheckbox.checked });
    console.log('[OPTIONS] Saved: soundEnabled =', enableSoundCheckbox.checked);
    showToast('Settings saved');
  });

  analyticsToggle.addEventListener('change', () => {
    chrome.storage.local.set({ analyticsEnabled: analyticsToggle.checked });
    console.log('[OPTIONS] Saved: analyticsEnabled =', analyticsToggle.checked);
    showToast('Settings saved');
  });

  resetDefaultsBtn.addEventListener('click', () => {
    chrome.storage.local.set({
      defaultTarget: 75,
      syncInterval: 45,
      notificationsEnabled: true,
      soundEnabled: false,
      analyticsEnabled: true
    });
    loadSettings();
    console.log('[OPTIONS] Reset all settings to defaults');
    showToast('Settings reset to defaults');
  });

  testNotificationBtn.addEventListener('click', () => {
    const iconUrl = chrome.runtime.getURL('icons/icon128.png');
    console.log('[TEST] Icon URL:', iconUrl);
    chrome.notifications.create('test-' + Date.now(), {
      type: 'basic',
      iconUrl: iconUrl,
      title: 'Test',
      message: 'Notifications are working!'
    }, (id) => {
      if (chrome.runtime.lastError) {
        console.error('[TEST] Failed:', chrome.runtime.lastError.message);
        alert('Failed: ' + chrome.runtime.lastError.message);
      } else {
        console.log('[TEST] Success, ID:', id);
      }
    });
  });

  applyDefaultBtn.addEventListener('click', async () => {
    const data = await chrome.storage.local.get(['snapshot', 'defaultTarget']);
    const subjects = data.snapshot || [];
    const defaultTarget = data.defaultTarget || 75;
    subjectsContainer.querySelectorAll('.target-input').forEach(input => {
      input.value = defaultTarget;
    });
    showToast('All targets set to ' + defaultTarget + '%. Click Apply Changes to save.');
  });

  resetAllBtn.addEventListener('click', () => {
    subjectsContainer.querySelectorAll('.target-input').forEach(input => {
      input.value = 75;
    });
    showToast('All targets reset to 75%. Click Apply Changes to save.');
  });

  applyChangesBtn.addEventListener('click', async () => {
    const inputs = subjectsContainer.querySelectorAll('.target-input');
    if (inputs.length === 0) {
      showToast('No subjects to save. Open ERP and sync first.');
      return;
    }
    const subjectTargets = {};
    let hasError = false;
    inputs.forEach(input => {
      const uuid = input.dataset.uuid;
      const val = parseInt(input.value);
      if (isNaN(val) || val < 0 || val > 100) {
        hasError = true;
        input.style.borderColor = '#f44336';
      } else {
        input.style.borderColor = '#ddd';
        subjectTargets[uuid] = val;
      }
    });
    if (hasError) {
      showToast('Target must be 0-100');
      return;
    }
    applyChangesBtn.textContent = 'Saving...';
    applyChangesBtn.disabled = true;
    await chrome.storage.local.set({ subjectTargets });
    console.log('[OPTIONS] Applied targets:', subjectTargets);
    setTimeout(() => {
      applyChangesBtn.textContent = '✅ Saved!';
      showToast('Targets saved successfully!');
      setTimeout(() => {
        applyChangesBtn.textContent = '✅ Apply Changes';
        applyChangesBtn.disabled = false;
      }, 1500);
    }, 500);
  });

  document.getElementById('clearAllDisputes').addEventListener('click', async () => {
    if (confirm('Remove ALL disputed entries?')) {
      await chrome.storage.local.set({ disputed: [] });
      console.log('[OPTIONS] Cleared all disputes');
      showToast('All disputes cleared!');
      await loadDisputed();
    }
  });

  clearDataBtn.addEventListener('click', () => {
    confirmModal.style.display = 'flex';
  });

  modalCancel.addEventListener('click', () => {
    confirmModal.style.display = 'none';
  });

  modalConfirm.addEventListener('click', async () => {
    await chrome.storage.local.clear();
    confirmModal.style.display = 'none';
    location.reload();
  });

  function showToast(message) {
    const toast = document.createElement('div');
    toast.style.cssText = 'position:fixed;bottom:24px;right:24px;background:#4caf50;color:white;padding:12px 20px;border-radius:8px;font-size:13px;z-index:9999;transition:opacity 0.5s;';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => { toast.style.opacity = '0'; }, 2000);
    setTimeout(() => { toast.remove(); }, 2500);
  }

  async function loadSettings() {
    const data = await chrome.storage.local.get([
      'defaultTarget', 'syncInterval', 'notificationsEnabled',
      'soundEnabled', 'analyticsEnabled'
    ]);
    console.log('[OPTIONS] Loaded settings:', data);
    defaultTargetInput.value = data.defaultTarget || 75;
    syncIntervalSelect.value = String(data.syncInterval || 45);
    enableNotificationsCheckbox.checked = data.notificationsEnabled !== false;
    enableSoundCheckbox.checked = data.soundEnabled === true;
    analyticsToggle.checked = data.analyticsEnabled !== false;
  }

  async function loadDisputed() {
    const { disputed = [] } = await chrome.storage.local.get('disputed');
    const container = document.getElementById('disputedList');
    const emptyMsg = document.getElementById('noDisputes');

    if (disputed.length === 0) {
      container.innerHTML = '';
      emptyMsg.style.display = 'block';
      return;
    }

    emptyMsg.style.display = 'none';
    container.innerHTML = disputed.map((d, idx) => `
      <div class="dispute-card" data-index="${idx}">
        <div class="dispute-info">
          <div class="dispute-subject">${d.course_name}</div>
          <div class="dispute-date">Disputed on: ${new Date(d.disputed_at).toLocaleString()}</div>
        </div>
        <button class="btn-resolve" data-index="${idx}">✅ Remove Dispute</button>
      </div>
    `).join('');

    container.querySelectorAll('.btn-resolve').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const idx = parseInt(e.target.dataset.index);
        await removeDispute(idx);
      });
    });
  }

  async function removeDispute(index) {
    const { disputed = [] } = await chrome.storage.local.get('disputed');
    const removed = disputed.splice(index, 1);
    await chrome.storage.local.set({ disputed });
    console.log('[OPTIONS] Removed dispute:', removed[0].course_name);
    showToast('Dispute removed!');
    await loadDisputed();
  }

  async function loadSubjects() {
    const data = await chrome.storage.local.get(['snapshot', 'subjectTargets', 'defaultTarget']);
    const subjects = data.snapshot || [];
    const subjectTargets = data.subjectTargets || {};
    const defaultTarget = data.defaultTarget || 75;

    if (subjects.length === 0) {
      subjectsContainer.innerHTML = '<p class="empty-state">Open ERP and click Sync Now to load subjects</p>';
      return;
    }

    const rows = subjects.map(s => {
      const target = subjectTargets[s.course_uuid] || defaultTarget;
      const pct = s.total_count > 0 ? ((s.present_count / s.total_count) * 100).toFixed(1) : '0';
      return `
        <tr>
          <td>${s.course_name}</td>
          <td>${s.course_code}</td>
          <td><input type="number" min="0" max="100" value="${target}" data-uuid="${s.course_uuid}" class="target-input"></td>
          <td>${pct}%</td>
        </tr>
      `;
    }).join('');

    subjectsContainer.innerHTML = `
      <table class="subjects-table">
        <thead>
          <tr><th>Subject Name</th><th>Code</th><th>Target %</th><th>Current %</th></tr>
        </thead>
        <tbody>${rows}</tbody>
      </table>
    `;
  }
});
